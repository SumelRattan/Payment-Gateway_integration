# Payment-Gateway-Integration
Payment Gateway Integration is developed using HTML,CSS and JavaScript. For payment gateway,Razorpay is used.

For demo card use

Card No:- 4111 1111 1111 1111

cvv:- Any

Validity:- Any

